<!DOCTYPE html>
<html>
<head>
    <title>Product Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* Customize styling as needed */
        body {
            background-color: #f0f2f5;
            padding-top: 60px; /* Adjust this value to make space for the sticky header */
        }
        .product-card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 20px 0;
        }
        .product-image {
            text-align: center;
            margin-bottom: 20px;
        }
        .product-name {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }
        .product-price {
            font-size: 20px;
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }
        .product-description {
            font-size: 16px;
            text-align: justify;
            margin-bottom: 20px;
        }
        .back-button {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <?php include("header.php"); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php
            if (isset($_GET['pid'])) {
                $product_id = $_GET['pid'];

                $conn = mysqli_connect("localhost", "root", "", "eshopdb");
                $qry = "select * from productmaster where pid='$product_id'";
                $result = mysqli_query($conn, $qry);

                if (mysqli_num_rows($result) > 0) {
                    $product = mysqli_fetch_assoc($result);

                    // Display product details
                    echo "<div class='product-card'>";
                    echo "<h1 class='product-name'>" . $product['pname'] . "</h1>";
                    echo "<p class='product-price'>Price: " . $product['pprice'] . "</p>";
                    echo "<div class='product-image'>";
                    echo "<img src='" . $product['pimage'] . "' class='img-responsive center-block' alt='" . $product['pname'] . "' width='200px'>";
                    echo "</div>";
                    // Display product description
                    if (!empty($product['pdescription'])) {
                        echo "<div class='product-description'>" . $product['pdescription'] . "</div>";
                    }
                    echo "<div class='back-button'>";
                    echo "<a href='./UserInterface.php' class='btn btn-primary'>Back to Home</a>";
                    echo "</div>";
                    echo "</div>"; // Close product-card
                } else {
                    echo "Product not found.";
                }

                mysqli_close($conn);
            } else {
                echo "Product ID not provided.";
            }
            ?>
        </div>
    </div>
</div>
<footer><?php include("footer.php"); ?></footer>
</body>
</html>
