<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("location: login_page.php");
    exit;
}

// Database connection setup (replace with your connection details)
$host = "localhost";
$username = "root";
$password = "";
$database = "eshopdb";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $currentPassword = $_POST["current_password"];
    $newPassword = $_POST["new_password"];

    // Get user's current password from the database
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_pwd FROM usermaster WHERE user_id = '$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $storedPassword = $row["user_pwd"];

        // Verify current password
        if (password_verify($currentPassword, $storedPassword)) {
            // Hash the new password before storing it
            $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update the user's password in the database
            $updateSql = "UPDATE usermaster SET user_pwd = '$hashedNewPassword' WHERE user_id = '$user_id'";
            if ($conn->query($updateSql) === TRUE) {
                echo "Password updated successfully!";
            } else {
                echo "Error updating password: " . $conn->error;
            }
        } else {
            echo "<h3>Incorrect current password.</h3>";
        }
    } else {
        echo "User not found.";
    }
}

$conn->close();
?>


