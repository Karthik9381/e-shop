<!DOCTYPE html>
<html>
    <head>
        <title>user</title>
        <meta name="viewport"  content=" width=device-width, intial-scale=1">
            
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>


<style>
    .hai{
        width:500px;
        border-radius:5px;
        height:35px; 
        border-color:whitesmoke;
        font-family:sans-serif;
    }
    textarea{
        height:150px;
        width: 500px;
         border-radius:5px;
         border-color:whitesmoke;     
    }
  
  <?php
  session_start();
  if(!isset($_SESSION['user_id'])){
      header("location:login_page.php");
  }
?>
    
</style>
		

    </head>
    <body style="background-color:#f0f2f5;">
	<div class="container-fluid">
		 <?php include("header.php"); ?>
          
            <div class="row">
                <div class="col-sm-12" style="height:700px;margin:50px">
                   
    <div class="container-fluid">
      
            <div class="row" style="">
                <div class="col-sm-12" align="center" >
                   
                       
                    <form action="" class=".kar" style=" background-color:#38b6ff;padding:5px;border-radius: 5px; box-shadow: 5px 5px 6px -7px;width:600px;height:700px;margin-bottom:100px;row-gap:5%;">
                        <h3 float="center" style="font-family:'New Century Schoolbook',serif;letter-spacing:2px"><b>Shipping Page !</b></h3></legend>
                    
                                <table  align="center" style=" margin:30px;width:400px;height:600px;">
                                    <tr>
                        <td align="left" style=""><b>User Name</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder=" Username" class="hai"></td></tr>
                            <tr><td align="left"><b>E-mail ID</b></td></tr>
                            <tr>
                                <td><input type="email" placeholder=" User@gmail.com" class="hai"></td></tr>
                            <tr>
                                <td align="left">
                                    <b>Phone Number</b>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" placeholder="phone number" class="hai">
                                </td>
                            </tr>
                            <tr style="margin-top:30px">
                                <td align="left" style="margin-top:">
                                    <b>Address</b>
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <textarea type="text" placeholder="Enter your Address" ></textarea>

                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <input type="checkbox" value="confirm" name="confrim" style="margin-top:10px"><b> I accept all terms and conditons...</b>
                                </td>
                            </tr>
                           
                            <td><button type="submit"  style="background-color:#0074d9; border-radius:5px;height:50px;border-color:#0074d9;width:500px;margin-top:10px;letter-spacing:1px; "><b>Submit</b></button></td></tr>
                        </table>
                        
                    </form>
                       
                </div>        
                </div>
        </div>

                </div>
                    
                
            </div>
                            
                                
                          
			
			
      
        </div>
       
    </body>
    <footer><?php include("footer.php"); ?></footer>
</html>