<!DOCTYPE html>
<html>
    <head>
        <title>Addnewproduct</title>
        <meta name="viewport"  content=" width=device-width, intial-scale=1">
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php
  session_start();
  if(!isset($_SESSION['user_id'])){
      header("location:login_page.php");
  }

if(isset($_post['add-newproduct']))
{
    $pid =$_post['txt_pid'];
     $pname=$_post['txt_pname'];
    
     $pprice=$_post['txt_pprice'];
        $ptype =$_post['txt_ptype'];
     $pimage="";
     /*$from=$_FILES['pimage']['tmp_name'];
     $to=$_SERVER[]./"e-shop/pimages".$_FILES['pimage']['name'];*/
     
   
 $link=mysqli_connect("localhost","root","","eshopdb");
  $qry="insert into productmaster values($pid,'$pname','$pprice','$ptype','$pimage')";
 mysqli_query($link, $qry);
}

?>
<style>
    form{
        background-color:#38b6ff;
        padding:5px;
        border-radius: 5px;
        box-shadow: 5px 5px 6px -7px;
        width:600px;
        margin-bottom:50px; 
    }
    button{
        border-radius:5px;
        height:50px;
        width:500px;
        border-color:blue;
    }
    .input{
        width:400px;
        border-radius:5px;
        height:35px; 
        border-color:whitesmoke; 
    }
</style>
		
    </head>
    <body style="background-color:#f0f2f5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12" align="center" >
                   
                         <h3 float="center"><b>Add New Product</b></h3></legend>
                <form action="#" method="post" enctype="multipart/form-data">
                       
                        <table  align="center" style="margin:30px;width:400px;height:600px;" class="">
                            <tr><td align="left" style=""><b>Model Id</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="IKJ808ks" name="txt_pid"class="input form-control"></td></tr>
                            <tr><td align="left"><b>Name</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="Redmi k20pro"name="txt_pname" class="input form-control"></td></tr>
                            <tr><td align="left"><b>Price</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="25000"name="txt_ptype" class="input form-control"></td></tr>
                            <tr><td align="left"><b>Type</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="Smartphone" name="txt_price"class="input form-control"></td>
                                 <tr><td align="left"><b>Image</b></td></tr>
                                 <tr>
                                     <td>
                                         <input type="file" placeholder="" style="float:right;background-color:white;border-color:whitesmoke "class="input">
                                     </td>
                                 </tr>
                            <tr>
                            <td><button type="submit" class="btn-primary" style="width:400px;margin-top:10px;letter-spacing:1px "><b>Submit</b></button></td></tr>
                        </table>
                        
                    </form>
                       
                            
                </div>
        </div>


