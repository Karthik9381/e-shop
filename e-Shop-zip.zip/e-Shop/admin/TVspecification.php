<!DOCTYPE html>
<html>
    <head>
        <title>TV Specification Page</title>
        <meta name="viewport"  content=" width=device-width, intial-scale=1">
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
    form{
        background-color:#38b6ff;
        padding:5px;
        border-radius: 5px;
        box-shadow: 5px 5px 6px -7px;
        width:600px;
       height:1050px; 
        margin-bottom:50px; 
    }
     button{
        border-radius:5px;
        height:50px;
        width:500px;
        border-color:blue;
        margin-top:10px;
        letter-spacing:1px;
    }
    .input{
        width:500px;
        border-radius:5px;
        height:35px; 
        border-color:whitesmoke; 
    }
    table{
        margin-top:5px; 
        width:500px;
        height:1000px;
        
    }
</style>
		
    </head>
    <body style="background-color:#f0f2f5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12" align="center" >
                   
                         <h3 float="center"><b>TV Specification!</b></h3></legend>
                    <form action="">
                       
                        <table  align="center" style="">
                             <tr><td><b>IN The Box</b>
                                <textarea type="text" placeholder="" style="height:100px;width:400px "></textarea></td>
                            </tr>
                            <tr><td align="left"><b>Color</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="color" class="input"></td></tr>
                            <tr><td align="left"><b>Display Size</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="15-Inch" class="input"></td></tr>
                            <tr><td align="left"><b>Screen Type</b></td></tr>
                            <tr>
                                <td><input type="password" placeholder="Screen Type" class="input"></td></tr>
                            <tr><td align="left"><b>HD Technology & Resolution</b></td></tr>
                            <tr>
                                <td><input type="password" placeholder="Screen Type" class="input"></td></tr>
                            <tr style="margin:5px"><td align="left" style=""><b>Smart TV :</b>
                                
		  <label style="margin-left:90px"><input class="btn2" type="radio" name="select" value="" /> Yes</label>
               <label style="margin-left:40px"><input type="radio" name="select" value=""/> No</label>
		</td></tr>
                          <tr style="margin:5px"><td align="left" style=""><b>Motion Sensor:</b>
                                
		  <label style="margin-left:54px"><input class="btn2" type="radio" name="click" value="" /> Yes</label>
               <label style="margin-left:40px"><input type="radio" name="click" value=""/> No</label>
		</td></tr>
                         <tr><td align="left"><b>HDMI</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="HDMI" class="input"></td></tr>
                            <tr><td align="left"><b>USB</b></td></tr>
                            <tr>
                                <td><input type="text" placeholder="8.0" class="input"></td></tr> 
                             <tr style="margin:5px"><td align="left" style=""><b>Bulit In Wifi :</b>
                                
		  <label style="margin-left:90px"><input class="btn2" type="radio" name="select" value="" /> Yes</label>
               <label style="margin-left:40px"><input type="radio" name="select" value=""/> No</label>
		</td></tr>
                             <tr>
                                 <td align="left"><b>Lunch Year</b>   
                                 </td>
                             </tr>
                             <tr>
                                 <td>
                                     <input type="date" class="input">
                                 </td>
                             </tr>
                              <tr style="margin:5px"><td align="left" style=""><b>Wall mount included:</b>
                                
		  <label style="margin-left:90px"><input class="btn2" type="radio" name="y" value="" /> Yes</label>
               <label style="margin-left:40px"><input type="radio" name="y" value=""/> No</label>
		</td></tr>
                             <tr>
                            <td><button type="submit" class="btn-primary" style=" "><b>Submit</b></button></td></tr>
                        </table>
                        
                    </form>
                       
                            
                </div>
        </div>


