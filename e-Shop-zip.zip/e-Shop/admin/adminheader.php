<div class="row" height="200px" style="background-color:#38b6ff;">
                    <div class="col-sm-2" class="logo">
                    <img align="center" src="newlogo.jpg" alt="" height="100px"style="margin-top:10px;margin-left:50px" >
                    </div>

               
               
		 <div class="col-sm-8"  style="height:100px;">
                 
                     <h2 method="post" class="horizontal" style="margin-top:30px;padding-top:10px;margin-left:20px;font-family:fantasy">Admin Panel</h2>
            
       
                 </div> <div class="col-sm-1"  style="height:100px; margin-top: 30px;padding-top:10px">
        <div class="dropdown">
            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" style="background-color:#0e3a4d"/><b> My Account </b> <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="">Profile</a></li>    
                <li><a href="Adminregistration.php">Register</a></li>
                <li><a href="">Login</a></li>
                 <li><a href="">Logout</a></li>
               
            </ul>
        </div>
    </div>
    
</div>
  <div class="row">
            <nav class="col-sm-2 navbar-inverse" style="background-color:#0e3a4d;border-radius:5px; ">
                <ul class=" navbar-left nav" style="font-weight:bolder;">
                    <li style=""><a href="">Home</a></li>
                    <li class="dropdown"><a href="" class="dropdown-toggle" data-toggle="dropdown">Products<span
                                class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="Addnewproduct.php">Add New Products</a></li>
                            <li><a href="">View Products</a></li>
                        </ul>

                    <li class="dropdown"><a href="" class="dropdown-toggle" data-toggle="dropdown">Users<span
                                class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="AdminRegistration.php">Add New Users</a></li>
                            <li><a href="">View Users</a></li>
                        </ul>
                    <li class="dropdown"><a href="" class="dropdown-toggle" data-toggle="dropdown">Orders<span
                                class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="">View All Orders</a></li>
                        </ul>
                </ul>
            </nav>
            <div class="col-sm-10" style="height:600px"></div>


        </div>
           
                   
                
