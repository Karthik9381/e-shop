<div class="row">
    <div class="col-sm-12 text-center" style="background-color:#0e3a4d; height:40px; padding-top: 5px; color:white; ">
        <h5 style="font-weight:bolder  ">&copy; rights are reserved by kartheek </h5>
    </div>
</div>