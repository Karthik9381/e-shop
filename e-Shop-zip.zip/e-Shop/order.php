<!DOCTYPE html>
<html>
    <head>
        <title>user</title>
        <meta name="viewport"  content=" width=device-width, intial-scale=1">
            
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>


<style>
    input{
        text-align:center;
    }
 
    
</style>
<?php
  session_start();
  if(!isset($_SESSION['user_id'])){
      header("location:login_page.php");
  }
  $msg="";
  if(isset($_POST['submit'])){
      $name=$_POST['username'];
      $add=$_POST['address'];
      $address=$name."<br>".$add;
      $payment=$_POST['payment'];
      $amount=$_SESSION['amount'];
      $pid=$_COOKIE['cart'];
      $date=date("y-m-d");
      $status="Undeliver";
      $user_id=$_SESSION['user_id'];
      $qry="insert into orders(user_id,pid,order_date,amount,address,payment,status) values($user_id,'$pid','$order_date',$amount,'$address','$payment','$status')";
      $conn=mysqli_connect("localhost","root","","eshopdb");
      mysqli_query($conn, $qry);
      if(mysqli_affected_rows($conn)>0)
      {
          $msg="<font color='green'>Order Placed !!!!</font>";
          setcookie("cart","");
      }
 else {
          $msg="<font color='red'>Error in placing order.Try Again</font>";
      }
      
  }
?>
		

    </head>
    <body style="background-color:#f0f2f5;">
	<div class="container-fluid">
		 <?php include("header.php"); ?>
            
            <div class="row">
                <div class="col-sm-12" style="height:700px ">
                    <h1 align='center'> Place Order </h1>
                     <div class="row">
            <div class="col-sm-12">
                <form align="center" method="post">
                    <table  align="center" style="width">
                        <tr>
                            <td style="text-align:left">
                                User Name
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="username" placeholder="Enter your name">
                            </td>
                        </tr>
                         <tr>
                            <td style="text-align:left">
                                Address
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <textarea type="text" name="address" placeholder="Enter your Address"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Payment Method:
                            </td>
                            <td>
                                <input type="radio" name="payment">Net Banking
                            </td>
                             <td>
                                <input type="radio" name="payment">Debit Card
                            </td>
                             <td>
                                <input type="radio" name="payment">Cash On Delivery
                            </td>
                            <td>
                                <input type="radio" name="payment">Credit Card
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <input type="submit" name="submit" placeholder="Submit">
                            </td>
                        </tr>
                    </table>
                    <?php $msg
                            ?>
                </form>
            </div>
            
        </div>
                </div>
                    
                
            </div>
                            
                                
                          
			
			
     
        </div>
       
    </body>
    <footer><?php include("footer.php"); ?></footer>
</html>